import sqlite3
def loginDatabase():
    try:
        conn = sqlite3.connect('database.db')
        print("Opened database successfully")
        curr = conn.cursor()
        curr.execute("CREATE TABLE IF NOT EXISTS LOGIN(EMAIL TEXT PRIMARY KEY NOT NULL, PASSWORD TEXT)")
        print("Table created successfully")
    except:
        print("Table creation failed")
    finally:
        curr.close()
        conn.close()

def registrationDatabase():
    try:
        conn = sqlite3.connect('database.db')
        print("Opened database successfully")
        curr = conn.cursor()
        curr.execute("CREATE TABLE IF NOT EXISTS REGISTRATION(NAME TEXT, EMAIL TEXT PRIMARY KEY NOT NULL, CONTACTNUMBER INT, DEPARTMENT TEXT, DESIGNATION TEXT, TEACHINGHOURS REAL, LABHOURS REAL, INSTITUTERESPONSIBILITY TEXT, DEPARTMENTRESPONSIBILITY TEXT, VERIFIED TEXT)")
        print("Table created successfully")
    except:
        print("Table creation failed")
    finally:
        curr.close()
        conn.close()

def priorityCodeDatabase():
    try:
        conn = sqlite3.connect('database.db')
        curr = conn.cursor()
        print("Opened database successfully")
        curr.execute("CREATE TABLE IF NOT EXISTS PRIORITYCODE(INDIRECTRESPONSIBILITY TEXT NOT NULL, CODE REAL)")
        print("Table created successfully")
    except:
        print("Table creation failed")
    finally:
        curr.close()
        conn.close()

def verifiedOrNotDatabase():
    try:
        conn = sqlite3.connect('database.db')
        curr = conn.cursor()
        print("Opened database successfully")
        curr.execute("CREATE TABLE IF NOT EXISTS VERIFIEDORNOT(NAME TEXT PRIMARY KEY NOT NULL, DEPOK TEXT, DESOK TEXT, TEACHOK TEXT, LABOK TEXT, INSTRESPOK TEXT, DEPARTRESPOK TEXT)")
        print("Table created successfully")
    except:
        print("Table creation failed")
    finally:
        curr.close()
        conn.close()

if __name__ == '__main__':
    loginDatabase()
    registrationDatabase()
    priorityCodeDatabase()
    verifiedOrNotDatabase()
