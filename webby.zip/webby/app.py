#implement datatype and datasize check conditions because JS can be overridden
#login session cookies


from __future__ import print_function
from flask import Flask, render_template, url_for, request, flash, make_response, session, redirect, abort

from googleapiclient.discovery import build
from apiclient import errors
from httplib2 import Http
from email.mime.text import MIMEText
import base64
from google.oauth2 import service_account
import sqlite3
import bcrypt
import os


app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)




'''
@app.before_request
def requirelogin():
    allowed_routes = ['/', '/registration/', '/facultylogin/',  ]
    if 'email' not in session and request.endpoint not in allowed_routes :
        return redirect(url_for('adminlogin'))
'''

@app.route("/", methods=['GET', 'POST'] )
def homepage():
    return render_template('index.html')




@app.route("/registration/", methods=['GET','POST'])
def registration():
    if request.method != 'POST' :
        return render_template("reg.html")

    else:
        msg=None
        conn = sqlite3.connect('database_file/database.db')
            #lower() to all the form data

        name = request.form['name']
        email = request.form['email']
        contactNumber = request.form['contactNumber']
        department = request.args.get('text')
        designation = request.args.get('Designation')
        teachingHours = request.form['teachingHours']
        labHours = request.form['labHours']
        instituteResponsibility = request.form['instituteResponsibility']
        departmentResponsibility = request.form['departmentResponsibility']
        password = request.form['password'].encode("utf-8")
        salt = bcrypt.gensalt()
        password_hashed = bcrypt.hashpw(password, salt)
        verify = 'no'
        try:
            cur = conn.cursor()
            cur.execute("INSERT INTO REGISTRATION(NAME, EMAIL, CONTACTNUMBER, DEPARTMENT, DESIGNATION,TEACHINGHOURS, LABHOURS, INSTITUTERESPONSIBILITY, DEPARTMENTRESPONSIBILITY, VERIFIED) VALUES(?,?,?,?,?,?,?,?,?,?)", (name, email, contactNumber, department, designation, teachingHours, labHours, instituteResponsibility, departmentResponsibility, verify))
            conn.commit()

            cur.execute("INSERT INTO LOGIN(EMAIL, PASSWORD) VALUES(?, ?)", (email, password_hashed))
            conn.commit()
            cur.close()

            msg = "success"
        except :

            msg = "failure"

# on sumbit of registration, an ajax request to send msg and display the alert
        finally:
            conn.close()
            if msg == "success" :
                flash("Well done! Your data has been successfully recorded.")
                return render_template("reg.html")
            if msg == "failure" :
                flash("Change a few things up, and submit in a while")
                return redirect('/registration/')



@app.route("/facultylogin/", methods=['GET', 'POST'])
def login():
    if 'user' in session.keys():
        return redirect('/faculty/<facultyName>/')
    else:
        if request.method == 'GET' :
            return render_template('login.html', link = "faculty")
        else :

            email = request.form['email']
            password = request.form['password'].encode("utf-8")
            con = sqlite3.connect("database_file/database.db")
            cur = con.cursor()

            cur.execute("SELECT PASSWORD FROM LOGIN WHERE EMAIL = ?", (email,))
            stored_hash = cur.fetchone()[0]
            if bcrypt.hashpw(password, stored_hash) == stored_hash: #avoid SQL attacks
                session['user'] = email
                cur.execute("SELECT NAME FROM REGISTRATION WHERE EMAIL = ?", (email,))
                Name = cur.fetchone()[0]
                cur.close()
                con.close()
                return redirect(url_for('facultyData', facultyName = Name))
            else :
            #response = render_template("login.html")
            #response.set_cookie("userKey",  ,max_age=0)
                cur.close()
                con.close()
                flash('Incorrect Password')
                return render_template("login.html", link = "faculty")







@app.route("/faculty/<facultyName>/", methods=['GET', 'POST'])
def facultyData(facultyName):
    if 'user' in session.keys():
        email = session.get('user')
        if request.method == 'GET' :
            con = sqlite3.connect("database_file/database.db")
            cur = con.cursor()
            cur.execute("SELECT VERIFIED FROM REGISTRATION WHERE NAME = ?", (facultyName,))
            Status = cur.fetchone()[0]
            return render_template('landing.html', name = facultyName, status = Status)
    else:
        return redirect('/facultylogin/')


@app.route("/faculty/correct/<facultyName>/", methods=['GET', 'POST'])
def correction(facultyName):
    if 'user' in session.keys():
        email = session.get('user')
        if request.method == 'GET' :
            con = sqlite3.connect('database_file/database.db')
            cur = con.cursor()
            cur.execute("SELECT EMAIL, DEPARTMENT, DESIGNATION, TEACHINGHOURS, LABHOURS, INSTITUTERESPONSIBILITY, DEPARTMENTRESPONSIBILITY FROM REGISTRATION WHERE NAME = ?", (facultyName,))
            Data = [row for row in cur.fetchall()]
            cur.execute("SELECT * FROM VERIFIEDORNOT WHERE EMAIL = ?", (Data[0][0],))
            Status = [row for row in cur.fetchall()]
            cur.close()
            con.close()
            return render_template('correct.html', name = facultyName, status = Status, data = Data)
    else:
        return redirect('/facultylogin/')





@app.route("/faculty/display/<facultyName>/", methods=['GET', 'POST'])
def showData(facultyName):
    if 'user' in session.keys():
         email = session.get('user')
         con = sqlite3.connect("database_file/database.db")
         cur = con.cursor()
         cur.execute("SELECT * FROM REGISTRATION WHERE EMAIL = ?", (email,))
         cursor = [row for row in cur.fetchall()]
         cur.close()
         con.close()
         return render_template('facultyverify.html', name = cursor[0][0], email = cursor[0][1], contactNumber =cursor[0][2], department = cursor[0][3],
         designation = cursor[0][4], teachingHours = cursor[0][5], labHours = cursor[0][6], instituteResponsibility = cursor[0][7],
         departmentResponsibility = cursor[0][8])
    else:
        return redirect('/facultylogin/')




@app.route("/faculty/edit/<facultyName>/", methods=['GET', 'POST'])
def editData(facultyName):
    if 'user' in session.keys():
        email = session.get('user')
        if request.method != 'POST':
            con = sqlite3.connect("database_file/database.db")
            cur = con.cursor()
            cur.execute("SELECT CONTACTNUMBER, DEPARTMENT, DESIGNATION, TEACHINGHOURS, LABHOURS, INSTITUTERESPONSIBILITY, DEPARTMENTRESPONSIBILITY FROM REGISTRATION WHERE EMAIL = ?", (email,))
            data = [row for row in cur.fetchall()]
            return render_template("update.html", name = facultyName, contactNumber = data[0][0], department = data[0][1], designation = data[0][2], teachingHours = data[0][3], labHours = data[0][4], instituteResponsibility = data[0][5], departmentResponsibility = data[0][6])




        else :
            contactNumber = request.form['contactNumber']
            department = request.form['department']
            designation = request.form['designation']
            teachingHours = request.form['teachingHours']
            labHours = request.form['labHours']
            instituteResponsibility = request.form.get('instituteResponsibility')
            departmentResponsibility = request.form.get('departmentResponsibility')
            verify = 'no'
            conn = sqlite3.connect('database_file/database.db')
            cur = conn.cursor()
            cur.execute("UPDATE REGISTRATION SET CONTACTNUMBER = (?), DEPARTMENT = (?), DESIGNATION = (?),TEACHINGHOURS = (?), LABHOURS = (?), INSTITUTERESPONSIBILITY = (?), DEPARTMENTRESPONSIBILITY = (?), VERIFIED = (?) WHERE NAME = (?)", (contactNumber, department, designation, teachingHours, labHours, instituteResponsibility, departmentResponsibility, verify, facultyName))
            conn.commit()
            cur.close()
            conn.close()
            #flash('Data entered Successfully')
            return redirect('/')
    else:
        return redirect('/facultylogin/')





@app.route("/adminlogin/", methods=['GET', 'POST'])
def adminlogin() :
    #check for coolie and redirect to /admin/
    #everybody regosters using faculty link..;pull hod and oruncipapls data for backend verifictaiopn of afmin login...so same passwor..and nobidy else apart from hod/princi can access
    if 'user' in session.keys() and session.get('user') == 'admin':
        return redirect('/admin/')
    else:
        if request.method == 'GET' :
            return render_template("login.html", link = "admin")
        else :
            session.pop('user', None)
            con = sqlite3.connect("database_file/database.db")
            cur = con.cursor()

            email = request.form['email']
            password = request.form['password'].encode('utf-8')


            cur.execute("SELECT DESIGNATION FROM REGISTRATION WHERE EMAIL = ?", (email,))
            des = cur.fetchone()
            if des[0] == 'hod' :
                cur.execute("SELECT PASSWORD FROM LOGIN WHERE EMAIL = ?", (email,))
                passkey = cur.fetchone()
                stored_hash = passkey[0]
                if bcrypt.hashpw(password, stored_hash) == stored_hash :
                    session['user'] = 'admin'         #avoid SQL attacks
                    return redirect("/admin/") #table with all faculty name as links
                else :
                    flash('Incorrect Password')
                    return render_template("login.html", link = "admin")
            else :
                return abort(403)

            cur.close()
            con.close()







@app.route("/admin/")
def adminHomePage():
    if 'user' in session.keys() :
        if session.get('user') == 'admin':

    #html with a list of all faculty name and a checkbox saying data verified or not
            con = sqlite3.connect('database_file/database.db')
            cur = con.cursor()
            cur.execute("SELECT NAME, DEPARTMENT, VERIFIED FROM REGISTRATION ")
            data = [row for row in cur.fetchall()]
            cur.close()
            con.close()
            return render_template("names1.html", Data = data )
        else :
            return abort(403)
    #else unauthorised redirect to login
    else :
        return redirect('/adminlogin/')






@app.route("/admin/<facultyname>/", methods=['GET'])
def individualData(facultyname):
    if 'user' in session.keys() :
        if session.get('user') == 'admin':
            if request.method == "GET" :
                con = sqlite3.connect('database_file/database.db')
                cur = con.cursor()
                cur.execute("SELECT * FROM REGISTRATION WHERE NAME = ?", (facultyname,))
                cursor = [i for i in cur.fetchall()]
                print(len(cursor))
                cur.close()
                con.close()
            #return render_template('validate.html', name = cursor[0], email = cursor[1], contactNumber = cursor[2], department = cursor[3], designation = cursor[4], teachingHours = cursor[5], labHours = cursor[6], instituteResponsibility = cursor[7], departmentResponsibility = cursor[8])
                return render_template('facultyvalidate.html', Cursor = cursor)
        else :
            return abort(403)
    else :
        return redirect('/adminlogin/')






@app.route("/admin/verification/<facultyname>/", methods=['POST'])
def verify(facultyname):
    if 'user' in session.keys() :
        if session.get('user') == 'admin':
            if request.method == 'POST' :
                claim = {}
                alert = []
                depOK = request.form.get('depOK')
                desOK = request.form.get('desOK')
                teachOK = request.form.get('teachOk')
                labOK = request.form.get('labOK')
                instRespOK = request.form.get('instRespOK')
                departRespOK = request.form.get('departRespOk')

                con = sqlite3.connect('database_file/database.db')
                cur = con.cursor()
                cur.execute("REPLACE INTO VERIFIEDORNOT(EMAIL, DEPOK, DESOK, TEACHOK, LABOK, INSTRESPOK, DEPARTRESPOK) VALUES(?,?,?,?,?,?,?)", (facultyname, depOK, desOK, teachOK, labOK, instRespOK, departRespOK))
                con.commit()
                if depOK != True :
                    claim = {'dep':False}
                else :
                    claim = {'dep':True}
                if desOK != True :
                    claim = {'des':False}
                else :
                    claim = {'des':True}
                if teachOK != True :
                    claim = {'teach':False}
                else:
                    claim = {'teach':True}
                if labOK != True :
                    claim = {'lab':False}
                else:
                    claim = {'lab':True}
                if instRespOK != True :
                    claim = {'instResp':False}
                else:
                    claim = {'instResp':True}
                if departRespOK != True :
                    claim = {'departResp':False}
                else :
                    claim = {'departResp':True}

                if claim.get('dep') != False and claim.get('des') != False and claim.get('teach') != False and claim.get('lab') != False and claim.get('instResp') != False and claim.get('departResp') != False :
                    con = sqlite3.connect('database_file/database.db')
                    cur = con.cursor()
                    cur.execute("UPDATE REGISTRATION SET VERIFIED = 'yes' WHERE NAME = (?)", (facultyname,))
                    con.commit()
                    cur.close()
                    con.close()
                    return redirect('/admin/')
                else :
                    for key in claim.keys():
                        if claim[key] != True :
                            alert.append(key)
                    con = sqlite3.connect('database_file/database.db')
                    cur = con.cursor()
                    cur.execute("SELECT EMAIL FROM REGISTRATION WHERE NAME=(?)", (facultyname,))
                    emaillist = cur.fetchall()
                    cur.close()
                    con.close()
                    return redirect('/')
        else:
            return abort(403)
    else :
        return redirect('/adminlogin/')

'''
                # Email variables. Modify this!
                    EMAIL_FROM = 'harsha.prd@gmail.com'
                    EMAIL_TO = emaillist[0][0]
                    EMAIL_SUBJECT = '"WorkHouse by BMSIT - Invalid Data entered"'
                    EMAIL_CONTENT = f"Hello {facultyname},\n\nWe just about realised that the credentials({item for item in alert}) you entered at ours is incorrect. \nClick here to address them. \n\nRegards,\v\v This is an automated email, kindly do not reply."



                    def create_message(sender, to, subject, message_text):
                        """Create a message for an email.
                        Args:
                        sender: Email address of the sender.
                        to: Email address of the receiver.
                        subject: The subject of the email message.
                        message_text: The text of the email message.
                        Returns:
                        An object containing a base64url encoded email object.
                        """
                        message = MIMEText(message_text)
                        message['to'] = to
                        message['from'] = sender
                        message['subject'] = subject
                        return {'raw': base64.urlsafe_b64encode(message.as_string())}

                    def send_message(service, user_id, message):
                        """Send an email message.
                        Args:
                        service: Authorized Gmail API service instance.
                        user_id: User's email address. The special value "me"
                        can be used to indicate the authenticated user.
                        message: Message to be sent.
                        Returns:
                        Sent Message.
                        """
                        try:
                            message = (service.users().messages().send(userId=user_id, body=message)
                            .execute())
                            print('Message Id: %s' % message['id'])
                            return message
                        except errors.HttpError as error:
                            print('An error occurred: %s' % error)

                    def service_account_login():
                        SCOPES = ['https://www.googleapis.com/auth/gmail.send']
                        SERVICE_ACCOUNT_FILE = 'credentials.json'

                        credentials = service_account.Credentials.from_service_account_file(
                        SERVICE_ACCOUNT_FILE, scopes=SCOPES)
                        delegated_credentials = credentials.with_subject(EMAIL_FROM)
                        service = build('gmail', 'v1', credentials=delegated_credentials)
                        return service

                #service = service_account_login()
                # Call the Gmail API
                    message = create_message(EMAIL_FROM, EMAIL_TO, EMAIL_SUBJECT, EMAIL_CONTENT)
                    sent = send_message(service,'me', message) '''


        #send out mails to faculty with the incorrectly entered data field



@app.route("/logout/")
def logout() :
    session.pop('user', None)
    return redirect('/')

@app.errorhandler(404)
def fun_404(error):
    return render_template("404.html"), 404

@app.errorhandler(403)
def fun_404(error):
    return render_template("403.html"), 403





























if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0")
